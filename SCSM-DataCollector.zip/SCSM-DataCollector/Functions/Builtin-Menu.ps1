Function DataCollector-Menu
{
	function Main-Menu
	{
		param (
			[string]$Title = 'System Center Operations Manager: Data Collector'
		)
		Clear-Host
		Write-Host "================ " -NoNewline -ForegroundColor DarkYellow
		sleep -Milliseconds 120
		Write-Host $Title -ForegroundColor Cyan -NoNewline
		sleep -Milliseconds 120
		Write-Host " ================" -ForegroundColor DarkYellow
		sleep -Milliseconds 120
		
		Write-Host "1" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "1" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather as much data as possible."
		
		Write-Host "2" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather information from specific Windows Agent(s)."
		
		Write-Host "3" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "3" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather minimum information."
		
		Write-Host "Q" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "Q" -NoNewline -ForegroundColor Green
		Write-Host "`' to Quit."
	}
	function Sub-Menu-All
	{
		param (
			[string]$Title = 'System Center Operations Manager: Data Collector - Gather Everything'
		)
		Clear-Host
		Write-Host "================ " -NoNewline -ForegroundColor DarkYellow
		sleep -Milliseconds 120
		Write-Host $Title -ForegroundColor Cyan -NoNewline
		sleep -Milliseconds 120
		Write-Host " ================" -ForegroundColor DarkYellow
		sleep -Milliseconds 120
		
		Write-Host "1a" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "1a" -NoNewline -ForegroundColor Green
		Write-Host "`' to also gather information from specific Windows Agent(s)."
		
		Write-Host "1b" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "1b" -NoNewline -ForegroundColor Green
		Write-Host "`' to continue and start script."
		
		Write-Host "Q" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "Q" -NoNewline -ForegroundColor Green
		Write-Host "`' to Quit."
	}
	function Sub-Menu-SpecificAgents
	{
		param (
			[string]$Title = 'System Center Operations Manager: Data Collector - Specific Agents'
		)
		Clear-Host
		Write-Host "================ " -NoNewline -ForegroundColor DarkYellow
		sleep -Milliseconds 120
		Write-Host $Title -ForegroundColor Cyan -NoNewline
		sleep -Milliseconds 120
		Write-Host " ================" -ForegroundColor DarkYellow
		sleep -Milliseconds 120
		
		Write-Host "2a" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2a" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather minimum information from Windows Agent(s) + All Management Servers in Management Group."
		
		Write-Host "2b" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2b" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather Multiple types of information from Windows Agent(s) + All Management Servers in Management Group."
		
		Write-Host "2c" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2c" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather Event Logs Only (Application, System, Operations Manager) from Windows Agent(s) + All Management Servers in Management Group."
		
		Write-Host "2d" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2d" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather Run As Accounts Only + get minimum information from specific Windows Agent(s) and All Management Servers in Management Group."
		
		Write-Host "2e" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2e" -NoNewline -ForegroundColor Green
		Write-Host "`' to check Certificates Only for specific Windows Agent(s) + All Management Servers in Management Group."
		
		Write-Host "2f" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2f" -NoNewline -ForegroundColor Green
		Write-Host "`' to check Check TLS against specific Windows Agent(s) and All Management Servers in Management Group."
		
		Write-Host "2g" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2g" -NoNewline -ForegroundColor Green
		Write-Host "`' to check Export Management Packs + get minimum information from specific Windows Agent(s) and All Management Servers in Management Group."
		
		Write-Host "2h" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2h" -NoNewline -ForegroundColor Green
		Write-Host "`' to export Rules and Monitors + get minimum information from specific Windows Agent(s) and All Management Servers in Management Group."
		
		Write-Host "2i" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2i" -NoNewline -ForegroundColor Green
		Write-Host "`' to export MSInfo32 information from specific Windows Agent(s) + All Management Servers in Management Group."
		
		Write-Host "2j" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2j" -NoNewline -ForegroundColor Green
		Write-Host "`' to export Group Policy Results from specific Windows Agent(s) and All Management Servers in Management Group."
		
		Write-Host "2k" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2k" -NoNewline -ForegroundColor Green
		Write-Host "`' to gather SQL Error Logs + get minimum information from specific Windows Agent(s) and All Management Servers in Management Group."
		
		Write-Host "2l" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "2l" -NoNewline -ForegroundColor Green
		Write-Host "`' to ping the Management Server(s) in Management Group from each Windows Agent(s) to verify connectability (output at bottom of `'General Information.txt`' file in zip output) + get minimum information from specific Windows Agent(s) and All Management Servers in Management Group."
		
		Write-Host "Q" -NoNewline -ForegroundColor Green
		Write-Host ": Type `'" -NoNewline
		Write-Host "Q" -NoNewline -ForegroundColor Green
		Write-Host "`' to Quit."
	}
	
	
	do
	{
		Main-Menu
		$selection = $null
		$selection = Read-Host "Please make a selection"
		switch ($selection)
		{
			'1' {
				
				do
				{
					Sub-Menu-All
					$selection = $null
					$selection = Read-Host "Please make a selection"
					switch ($selection)
					{
						'1a'
						{
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -GetRulesAndMonitors -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs  -Yes
								}
								else
								{
									Start-ScomDataCollector -GetRulesAndMonitors -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs  -Yes
								}
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -GetRulesAndMonitors -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs 
								}
								else
								{
									Start-ScomDataCollector -GetRulesAndMonitors -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs 
								}
							}
						}
						'1b'
						{
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								Start-ScomDataCollector -GetRulesAndMonitors -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs  -Yes
							}
							if ($PermissionforSQL -like 'n')
							{
								Start-ScomDataCollector -GetRulesAndMonitors -GetRunAsAccounts -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs 
							}
							
						}
					}
				}
				until ($selection)
			}
			'2'
			{
				do
				{
					Sub-Menu-SpecificAgents
					$selection = $null
					$selection = Read-Host "Please make a selection"
					switch ($selection)
					{
						'2a' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -Yes
								}
								else
								{
									Start-ScomDataCollector -Yes
								}
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers
								}
								else
								{
									Start-ScomDataCollector
								}
							}
						}
						'2b' {
							Write-Host 'Options to choose from:
	graa = Run As Accounts
	ge = Event Logs
	cc = Check Certificates
	ct = Check TLS
	em = Export Management Packs
	gram = Get Rules and Monitors
	mi32 = Gather MSInfo32
	gp = Get Currently Configured Group Policy
	sql = Gather SQL Error Logs
'
							$argumentsforscript = Read-Host "Type your selection(s) seperated by spaces ex:`'ge gp sql`'"
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								$argumentsforscript
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers $argumentsforscript -Yes
								}
								else
								{
									Start-ScomDataCollector $argumentsforscript -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers $argumentsforscript
								}
								else
								{
									Start-ScomDataCollector $argumentsforscript
								}
							}
							
						}
						'2c' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -ge -Yes
								}
								else
								{
									Start-ScomDataCollector -ge -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -ge
								}
								else
								{
									Start-ScomDataCollector -ge
								}
							}
							
						}
						'2d' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -graa -Yes
								}
								else
								{
									Start-ScomDataCollector -graa -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -graa
								}
								else
								{
									Start-ScomDataCollector -graa
								}
							}
						}
						'2e' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -cc -Yes
								}
								else
								{
									Start-ScomDataCollector -cc -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -cc
								}
								else
								{
									Start-ScomDataCollector -cc
								}
							}
						}
						'2f' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -ct -Yes
								}
								else
								{
									Start-ScomDataCollector -ct -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -ct
								}
								else
								{
									Start-ScomDataCollector -ct
								}
							}
						}
						'2g' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -em -Yes
								}
								else
								{
									Start-ScomDataCollector -em -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -em
								}
								else
								{
									Start-ScomDataCollector -em
								}
							}
						}
						'2h' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -gram -Yes
								}
								else
								{
									Start-ScomDataCollector -gram -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -gram
								}
								else
								{
									Start-ScomDataCollector -gram
								}
							}
						}
						'2i' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -mi32 -Yes
								}
								else
								{
									Start-ScomDataCollector -mi32 -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -mi32
								}
								else
								{
									Start-ScomDataCollector -mi32
								}
							}
						}
						'2j' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -gp -Yes
								}
								else
								{
									Start-ScomDataCollector -gp -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -gp
								}
								else
								{
									Start-ScomDataCollector -gp
								}
							}
						}
						'2k' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -sql -Yes
								}
								else
								{
									Start-ScomDataCollector -sql -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -sql
								}
								else
								{
									Start-ScomDataCollector -sql
								}
							}
						}
						'2l' {
							[string]$Servers = $null
							[string]$Servers = Read-Host 'Please Type the Names of the Windows Agents (ex. Agent1.contoso.com, Agent2.contoso.com)'
							$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
							if ($PermissionforSQL -like 'y')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -PingAll -Yes
								}
								else
								{
									Start-ScomDataCollector -PingAll -Yes
								}
								
							}
							if ($PermissionforSQL -like 'n')
							{
								if ($Servers -ne $null)
								{
									Start-ScomDataCollector -Servers $Servers -PingAll
								}
								else
								{
									Start-ScomDataCollector -PingAll
								}
							}
						}
					}
				}
				until ($selection)
			} '3' {
				$PermissionforSQL = Read-Host "Does the following account have permissions to run SQL queries against the Operations Manager DB and Data Warehouse DB? `'$runningas`' Y/N"
				if ($PermissionforSQL -like 'y')
				{
					Start-ScomDataCollector -Yes
				}
				if ($PermissionforSQL -like 'n')
				{
					Start-ScomDataCollector
				}
			}
		}
		
	}
	until ($selection -ne $null)
}