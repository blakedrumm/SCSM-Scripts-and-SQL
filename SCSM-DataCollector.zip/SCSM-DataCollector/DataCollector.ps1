﻿<#
	.SYNOPSIS
		This script collects data from your SCSM Environment that can be very helpful in troubleshooting.
	
	.DESCRIPTION
		For full support, please run this script from a Management Server..
	
	.PARAMETER Servers
		Set additional servers to run checks against.
	
	.PARAMETER GetEventLogs
		Gather Event Logs with the localemetadata to ensure that you are able to open the Event log from any machine.
	
	.PARAMETER CheckCertificates
		Check the Certificates for validity for SCSM use, output in TXT format.
	
	.PARAMETER CheckTLS
		Check for TLS 1.2 Readiness, output in TXT format.
	
	.PARAMETER ExportMPs
		Export all Sealed/Unsealed MP's.
	
	.PARAMETER MSInfo32
		Export MSInfo32 for viewing in TXT Format.
	
	.PARAMETER GPResult
		Gathers Group Policy Results to verify Harmful Policies are not present, Generated in HTML and TXT Format.
	
	.PARAMETER CaseNumber
		Add an Optional Case Number to the Output of the Zip File.
	
	.PARAMETER SQLLogs
		Gather SQL Logs from ServiceManager and DataWarehouse DB's.
	
	.PARAMETER AssumeYes
		This will allow you to not be prompted for anything.
	
	.PARAMETER All
		Allows you to Specify all the Switches Available for use.
	
	.PARAMETER PingAll
		Ping every Management Server, including servers mentioned in -Servers switch.
	
	.EXAMPLE
		PS C:\> .\DataCollector.ps1 -Servers Agent1.contoso.com, Agent2.contoso.com -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -SQLLogs -GPResult -CaseNumber 0123456789  -AssumeYes
	
	.NOTES
		This script is intended for System Center Service Manager Environments. This is currently in development by the SCEM Support Team with Microsoft.
		
	.VERSION
		v0.1.0 - Feburary 13th, 2021
#>
param
(
	[Parameter(Mandatory = $false,
			   Position = 1)]
	[Alias('s')]
	[Array]$Servers,
	[Parameter(Mandatory = $false,
			   Position = 3)]
	[Alias('ge')]
	[switch]$GetEventLogs,
	[Parameter(Mandatory = $false,
			   Position = 4)]
	[Alias('cc')]
	[switch]$CheckCertificates,
	[Parameter(Mandatory = $false,
			   Position = 5)]
	[Alias('ct')]
	[switch]$CheckTLS,
	[Parameter(Mandatory = $false,
			   Position = 6)]
	[Alias('em')]
	[switch]$ExportMPs,
	[Parameter(Mandatory = $false,
			   Position = 8)]
	[Alias('mi32')]
	[switch]$MSInfo32,
	[Parameter(Position = 9)]
	[Alias('gp')]
	[switch]$GPResult,
	[Parameter(Mandatory = $false,
			   Position = 10)]
	[Alias('case')]
	[string]$CaseNumber,
	[Parameter(Position = 11)]
	[Alias('sql')]
	[switch]$SQLLogs,
	[Parameter(Mandatory = $false,
			   Position = 12)]
	[Alias('yes')]
	[switch]$AssumeYes,
	[Parameter(Mandatory = $false,
			   Position = 14)]
	[switch]$All,
	[Parameter(Mandatory = $false,
			   Position = 15)]
	[switch]$PingAll
)
$StartTime = Get-Date

Write-Host @"
===================================================================
==========================  Start of Script =======================
===================================================================
"@ -ForegroundColor DarkYellow
$runningas = $null
$runningas = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$runningas
#Get the script path
[string]$ScriptPath = $PSScriptRoot
$currentPath = $myinvocation.mycommand.definition
$OutputPath = "$ScriptPath\Output"
$CSVFile = $ScriptPath
Write-Host "Attempting to run the following command to unblock the Powershell Scripts under the current folder:`nGet-ChildItem $ScriptPath -Recurse | Unblock-File" -ForegroundColor Gray; Get-ChildItem $ScriptPath -Recurse | Unblock-File | Out-Null
$scriptout = [Array] @()
[String]$Comp = Resolve-DnsName $env:COMPUTERNAME -Type A | Select-Object -Property Name -ExpandProperty Name
$checkingpermission = "Checking for elevated permissions..."
$scriptout += $checkingpermission
Write-Host $checkingpermission -ForegroundColor Gray
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
[Security.Principal.WindowsBuiltInRole] "Administrator"))
{
	$nopermission = "Insufficient permissions to run this script. Attempting to open the PowerShell script ($currentPath) as administrator."
	$scriptout += $nopermission
	Write-Warning $nopermission
	# We are not running "as Administrator" - so relaunch as administrator
	$MyInvocation.BoundParameters.keys | sort | % { $PassedSwitches += "-$_ " }
	[array]$PassedValue = ($MyInvocation.BoundParameters.Values | Where{ 'True' -ne $_ }) -join ","
	if ($PassedSwitches)
	{
		Start-Process powershell.exe ("-NoProfile -NoExit -Command " + """& {0} {1} {2}""" -f $MyInvocation.MyCommand.Path, "$PassedSwitches", "$PassedValue") -Verb RunAs
	}
	else
	{
		Start-Process powershell.exe ("-NoProfile -NoExit -Command " + """& {0}""" -f $MyInvocation.MyCommand.Path) -Verb RunAs
	}
	break
}
else
{
	$permissiongranted = " Currently running as administrator - proceeding with script execution..."
	Write-Host $permissiongranted -ForegroundColor Green
}
$currentUser = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name).split('\')[1]
$omsdkUserOrig = (Get-WmiObject Win32_Service -Filter "Name='omsdk'").StartName -split '@'
if ($omsdkUserOrig)
{
	$omsdkUserSplit = ($omsdkUserOrig)[0]
	if ($omsdkUserOrig[1])
	{
		$omsdkUser = $omsdkUserOrig[1] + "\" + $omsdkUserOrig[0]
	}
	else
	{
		$omsdkUser = $omsdkUserOrig
	}
}
else
{
	$omsdkUserSplit = $currentUser
}
if ($omsdkUserOrig -notmatch $currentUser)
{
	do
	{
		if ($AssumeYes)
		{
			$answer = "n"
		}
		else
		{
			$currentPathFormat = """$currentPath"""
			$answer = Read-Host "Would you like to run this script as the SDK Account ($omsdkUser)? (Y/N)"
		}
	}
	until ($answer -eq "y" -or $answer -eq "n")
	if ($answer -eq "y")
	{
		try { $Credentials = Get-Credential -Message "Please provide credentials to run this script with" "$omsdkUser" }
		catch { Write-Warning $_ }
		try
		{
			$MyInvocation.BoundParameters.keys | sort | % { $PassedSwitches += "-$_ " }
			[array]$PassedValue = ($MyInvocation.BoundParameters.Values | Where{ 'True' -ne $_ }) -join ","
			if ($PassedSwitches)
			{
				if ($PassedValue)
				{
					Start-Process powershell.exe ("-NoProfile -NoExit -Command " + """& {0} {1} {2}""" -f $MyInvocation.MyCommand.Path, $PassedSwitches, "$PassedValue") -Credential $Credentials
				}
				else
				{
					Start-Process powershell.exe ("-NoProfile -NoExit -Command " + """& {0} {1}""" -f $MyInvocation.MyCommand.Path, $PassedSwitches) -Credential $Credentials
				}
			}
			else
			{
				Start-Process powershell.exe ("-NoProfile -NoExit -Command " + """& {0}""" -f $MyInvocation.MyCommand.Path) -Credential $Credentials
			}
			
		}
		catch { Write-Warning $_ }
		exit 0
	}
	
}

function Start-SCSMDataCollector
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $false,
				   Position = 1)]
		[Alias('s')]
		[Array]$Servers,
		[Parameter(Mandatory = $false,
				   Position = 3)]
		[Alias('ge')]
		[switch]$GetEventLogs,
		[Parameter(Mandatory = $false,
				   Position = 4)]
		[Alias('cc')]
		[switch]$CheckCertificates,
		[Parameter(Mandatory = $false,
				   Position = 5)]
		[Alias('ct')]
		[switch]$CheckTLS,
		[Parameter(Mandatory = $false,
				   Position = 6)]
		[Alias('em')]
		[switch]$ExportMPs,
		[Parameter(Mandatory = $false,
				   Position = 8)]
		[Alias('mi32')]
		[switch]$MSInfo32,
		[Parameter(Position = 9)]
		[Alias('gp')]
		[switch]$GPResult,
		[Parameter(Mandatory = $false,
				   Position = 10)]
		[Alias('case')]
		[string]$CaseNumber,
		[Parameter(Position = 11)]
		[Alias('sql')]
		[switch]$SQLLogs,
		[Parameter(Mandatory = $false,
				   Position = 12)]
		[Alias('yes')]
		[switch]$AssumeYes,
		[Parameter(Mandatory = $false,
				   Position = 14)]
		[switch]$All,
		[Parameter(Mandatory = $false,
				   Position = 15)]
		[switch]$PingAll
	)
	
	#=================================================================================
	#  SCSM Health SQL Query Collection Script
	#
	#  Author: Blake Drumm
	#  v1.0
	#=================================================================================
	# Begin MAIN script section
	#=================================================================================
	#Clear-Host
	# Check if this is running on a SCSM Management Server
	# Get SQLServer info from Registry if so
	
	# Service Manager Administrator Module
	$InstallationConfigKey = 'HKLM:\SOFTWARE\Microsoft\System Center\2010\Service Manager\Setup'
	$AdminModule = (Get-ItemProperty -Path $InstallationConfigKey -Name InstallDirectory).InstallDirectory + "Powershell\System.Center.Service.Manager.psd1"
	try { Import-Module -Name $AdminModule -ErrorAction Stop }
	catch { }
	
	# Service Manager Data Warehouse Module
	$InstallationConfigKey = 'HKLM:\SOFTWARE\Microsoft\System Center\2010\Service Manager\Setup'
	$DWModule = (Get-ItemProperty -Path $InstallationConfigKey -Name InstallDirectory).InstallDirectory + "Microsoft.EnterpriseManagement.Warehouse.Cmdlets.psd1"
	Import-Module -Name $DWModule -ErrorAction SilentlyContinue
	$MSKey = "HKLM:\SOFTWARE\Microsoft\System Center\2010\Common\Database"
	IF (Test-Path $MSKey)
	{
		# This is a management server.  Try to get the database values.
		$SCSMKey = "HKLM:\SOFTWARE\Microsoft\System Center\2010\Common\Database"
		$SCSMData = Get-ItemProperty $SCSMKey
		$global:ScsmDB_SQLServer = ($SCSMData).DatabaseServerName
		$global:ScsmDB_SQLServerOriginal = $ScsmDB_SQLServer
		$ScsmDB_SQLDBName = ($SCSMData).DatabaseName
		
		$scsmclass = get-scsmclass -name Microsoft.SystemCenter.ResourceAccessLayer.DwSdkResourceStore
		$scsminstance = Get-SCClassInstance -class $scsmclass
		$DatabaseInfo = Invoke-Command -ComputerName $scsminstance.Server -ScriptBlock {
			$DBInfo = Get-ItemProperty -path 'HKLM:SOFTWARE\Microsoft\System Center\2010\Common\Database'
			return $DBInfo
		}
		
		$StagingAndConfigDBServer = $DatabaseInfo | Select DatabaseServerName -ExpandProperty DatabaseServerName
		$StagingAndConfigDB = $DatabaseInfo | Select DatabaseName -ExpandProperty DatabaseName
		$RepositoryDB = $DatabaseInfo | Select RepositoryDatabaseName -ExpandProperty RepositoryDatabaseName
		$DataMartDatabaseName = $DatabaseInfo | Select DataMartDatabaseName -ExpandProperty DataMartDatabaseName
		$OMDataMartDB = $DatabaseInfo | Select OMDataMartDatabaseName -ExpandProperty OMDataMartDatabaseName
		$CMDataMartDB = $DatabaseInfo | Select CMDataMartDatabaseName -ExpandProperty CMDataMartDatabaseName
		$StagingDB = $DatabaseInfo | Select StagingDatabaseName -ExpandProperty StagingDatabaseName
		
		$global:DW_SQLServer = $StagingAndConfigDBServer
		$global:DW_SQLServerOriginal = $DW_SQLServer
		$DW_SQLDBName = $StagingAndConfigDB
		$mgmtserver = 1
	}
	ELSE
	{
		if ($RemoteMGMTserver)
		{
			$ComputerName = $RemoteMGMTserver
		}
		else
		{
			$ComputerName = read-host "Please enter the name of a SCSM management server $env:userdomain\$env:USERNAME has permissions on"
		}
		$Hive = [Microsoft.Win32.RegistryHive]::LocalMachine
		$KeyPath = 'SOFTWARE\Microsoft\System Center\2010\Common\Database'
		$ScsmDBServer = 'DatabaseServerName'
		$ScsmDBName = 'DatabaseName'
		$DWServer = 'DataWarehouseDBServerName'
		$DWDB = 'DataWarehouseDBName'
		$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($Hive, $ComputerName)
		$key = $reg.OpenSubKey($KeyPath)
		$ScsmDB_SQLServerOriginal = $key.GetValue($ScsmDBServer)
		$ScsmDB_SQLDBName = $key.GetValue($ScsmDBName)
		$DW_SQLServerOriginal = $key.GetValue($DWServer)
		$DW_SQLDBName = $key.GetValue($DWDB)
	}
	
	$Populated = 1
	
	. $ScriptPath`\Functions\SQL-Queries.ps1
	SQL-Queries
	
	#$TLSservers = import-csv $OutputPath\ManagementServers.csv
	$ManagementServers = Get-ScsmClass -name Microsoft.SystemCenter.HealthService | Get-SCClassInstance | Where { ($_.IsManagementServer -eq $true) -and ($_.IsGateway -eq $false) } | select DisplayName -ExpandProperty DisplayName
	[string[]]$TLSservers = $ManagementServers
	[string[]]$TLSservers += $global:DW_SQLServer
	[string[]]$TLSservers += $global:ScsmDB_SQLServer
	
	if ($Servers)
	{
		$Servers = ($Servers.Split(",").Split(" ") -replace (" ", ""))
		$Servers = $Servers | select -Unique
		foreach ($Server in $Servers)
		{
			[string[]]$TLSservers += $Server
		}
	}
	[array]$DNSCheckedServers = $null
	[string[]]$TLSservers = $TLSservers | select -Unique | Where { $null -ne $_ }
	try { $TLSservers | % { [array]$DNSCheckedServers += ([System.Net.Dns]::GetHostByName(("$_"))).Hostname } }
	catch { Write-Warning $_ }
	[array]$DNSVerifiedServers = [array]$DNSCheckedServers | select -Unique | Sort-Object
	#$TLSservers += "DC22"   # fictitious server added to simulate a no access/server down situation
	$DNSCount = ($DNSVerifiedServers).Count
	write-Output " "
	Write-Output "================================`nTesting Connectivity to Servers (Count: $DNSCount)"
	[string[]]$TestedTLSservers = @()
	foreach ($Rsrv in $DNSVerifiedServers)
	{
		Write-Host "  Testing $Rsrv" -ForegroundColor Gray
		$test = $null
		$test = test-path "\\$Rsrv\c$"
		if ($test)
		{
			Write-Host "    Successfully Accessed : $Rsrv" -ForegroundColor Green
			$TestedTLSservers += $Rsrv.Split(",")
		}
		else
		{
			Write-Host "    Access to $Rsrv Failed! Removing from Server Array! 
    Please verify that the server is online, and that your account has remote access to it.`n" -ForegroundColor Gray
		}
	}
	if ($CheckCertificates)
	{
		Write-Output " "
		Write-Output "================================`nStarting Certificate Checker"
		. $ScriptPath`\Functions\Certificate-Check.ps1
		foreach ($CertChkSvr in $TestedTLSservers)
		{
			Certificate-Check -Servers $CertChkSvr | Add-Content $OutputPath\$CertChkSvr.CertificateInfo.txt
		}
	}
	
	if ($CheckTLS)
	{
		Write-Output " "
		Write-Output "================================`nStarting TLS Checker"
		. $ScriptPath`\Functions\TLS-Checker.ps1
		. $ScriptPath`\Functions\Get-TLSRegKeys.ps1
		Start-TLSChecker -Servers $TestedTLSservers
		# This will be updated with CipherSuite checks at some point
		Get-TLSRegistryKeys -Servers $TestedTLSservers |
		sort server, protocol, type |
		ft Server, Protocol, Type, Disabledbydefault, IsEnabled -autosize |
		out-string |
		Out-File $OutputPath\TLS-RegistryKeys.txt
	}
	
	if ($GetEventLogs)
	{
		Write-Output " "
		Write-Output "================================`nStarting Event Log Gathering"
		. $ScriptPath`\Functions\Get-EventLog.ps1
		if ((Test-Path -Path "$OutputPath\Event Logs") -eq $false)
		{
			Write-Host "  Creating Folder: $OutputPath\Event Logs" -ForegroundColor Gray
			md "$OutputPath\Event Logs" | out-null
		}
		else
		{
			Write-Host "  Existing Folder Found: $OutputPath\Event Logs" -ForegroundColor Gray
			Remove-Item "$OutputPath\Event Logs" -Recurse | Out-Null
			Write-Host "   Deleting folder contents" -ForegroundColor Gray
			md "$OutputPath\Event Logs" | out-null
			Write-Host "    Folder Created: $OutputPath\Event Logs" -ForegroundColor Gray
		}
		foreach ($ElogServer in $TestedTLSservers)
		{
			Get-SCSMEventLogs -Servers $ELogServer
		}
		Write-Output " "
	}
	
	if ($ExportMPs)
	{
		try
		{
			if ($mgmtserver = 1)
			{
				Write-Output "================================`nStarting Management Pack Export"
				. $ScriptPath`\Functions\Export-ManagementPack.ps1
				MP-Export
    <#
        md $OutputPath\MPSealed | out-null
        try{
           (Get-SCSMManagementPack).where{$_.Sealed -eq $true} | Export-SCSMManagementPack -path $OutputPath\MPSealed
        }catch{
           
        }
    #>
				
			}
			else
			{
				Write-Warning "  Exporting Management Packs is only possible from a management server"
			}
		}
		catch { Write-Warning $_ }
	}
	if ($msinfo32)
	{
		write-output " "
		Write-Host "================================`nStarting MSInfo32 reporting"
		. $ScriptPath`\Functions\MsInfo32.ps1
		MSInfo32-Gathering
	}
	if ($SQLLogs)
	{
		try
		{
			if (Test-Path $OutputPath\SQL_ErrorLogLocation.csv)
			{
				write-output " "
				Write-Host "================================`nGathering SQL Logs"
				
				md "$OutputPath`\SQL Logs" | out-null
				$SQLOMLogLoc = Import-Csv $OutputPath\SQL_ErrorLogLocation.csv
				if ($DW_SQLServer -ne $ScsmDB_SQLServer)
				{
					$SQLDWLogLoc = Import-Csv $OutputPath\SQL_DWErrorLogLocation.csv
				}
				else
				{
					$SQLDWLogLoc = $null
				}
				
				$SQLOMLogLoc = ($SQLOMLogLoc).text
				$SQLOMLogLoc = $SQLOMLogLoc.split("'")[1]
				$SQLOMLogLoc = $SQLOMLogLoc.Replace(':', '$')
				$SQLOMLogLoc = $SQLOMLogLoc.replace("ERRORLOG", '*')
				if ($SQLDWLogLoc)
				{
					$SQLDWLogLoc = ($SQLDWLogLoc).text
					$SQLDWLogLoc = $SQLDWLogLoc.split("'")[1]
					$SQLDWLogLoc = $SQLDWLogLoc.Replace(':', '$')
					$SQLDWLogLoc = $SQLDWLogLoc.replace("ERRORLOG", '*')
					#$dest = "$locsrv" + "\$OutputPath"
				}
				
				
				if ($ScsmDB_SQLServer -ne $DW_SQLServer)
				{
					md "$OutputPath`\SQL Logs\ServiceManager" | out-null
					md "$OutputPath`\SQL Logs\DataWarehouse" | out-null
					Write-Host "    Copying " -NoNewline -ForegroundColor Cyan
					Write-Host "$ScsmDB_SQLDBName" -NoNewline -ForegroundColor Magenta
					Write-Host " Database SQL Logs from " -NoNewline -ForegroundColor Cyan
					Write-Host "$ScsmDB_SQLServer" -ForegroundColor Magenta
					copy -path \\$ScsmDB_SQLServer\$SQLOMLogLoc -Destination "$OutputPath`\SQL Logs\ServiceManager" | Out-Null
					Write-Host "    Copying " -NoNewline -ForegroundColor Cyan
					Write-Host "$DW_SQLDBName" -NoNewline -ForegroundColor Magenta
					Write-Host " Database SQL Logs from " -NoNewline -ForegroundColor Cyan
					Write-Host "$DW_SQLServer" -NoNewline -ForegroundColor Magenta
					copy -path \\$DW_SQLServer\$SQLDWLogLoc -Destination "$OutputPath`\SQL Logs\DataWarehouse" | Out-Null
				}
				if ($ScsmDB_SQLServer -eq $DW_SQLServer)
				{
					Write-Host "    Copying " -NoNewline -ForegroundColor Cyan
					Write-Host "$ScsmDB_SQLDBName" -NoNewline -ForegroundColor Magenta
					Write-Host " & " -NoNewline -ForegroundColor Cyan
					Write-Host "$DW_SQLDBName" -NoNewline -ForegroundColor Magenta
					Write-Host " Database SQL Logs from " -NoNewline -ForegroundColor Cyan
					Write-Host "$ScsmDB_SQLServer" -ForegroundColor Magenta
					copy -path \\$ScsmDB_SQLServer\$SQLOMLogLoc -Destination "$OutputPath`\SQL Logs\" | Out-Null
				}
				
			}
		}
		catch
		{
			Write-Warning 'Unable to locate the Log Location from SQL Query.'
		}
		
	}
	
	
	if ($GPResult)
	{
		write-output " "
		Write-Host "================================`nGathering Group Policy Result"
		foreach ($gpserver in $TestedTLSservers)
		{
			try
			{
				if ($gpserver -like $Comp)
				{
					mkdir -Path "$OutputPath`\GPResults" -Force | Out-Null
					Write-Host "    Gathering HTML Generated Output locally: `'" -NoNewLine -ForegroundColor Cyan
					Write-Host "$Comp" -NoNewLine -ForegroundColor Magenta
					Write-Host "`'" -ForegroundColor Cyan
					Start-Process -FilePath GPResult.exe -ArgumentList "/H $OutputPath`\GPResults\$Comp`-GPResult.html /F" -ErrorAction SilentlyContinue
					
					Write-Host "    Gathering Texted Generated Output locally: `'" -NoNewLine -ForegroundColor Cyan
					Write-Host "$Comp" -NoNewLine -ForegroundColor Magenta
					Write-Host "`'" -ForegroundColor Cyan
					Start-Process -FilePath GPResult.exe -ArgumentList "/Z /F" -ErrorAction SilentlyContinue | Out-File -FilePath "$OutputPath`\GPResults\$Comp`-GPResult-Z.txt"
				}
				else
				{
					Write-Host "    Gathering HTML Generated Output: `'" -NoNewLine -ForegroundColor Cyan
					Write-Host "$gpserver" -NoNewLine -ForegroundColor Magenta
					Write-Host "`'" -ForegroundColor Cyan
					Start-Process -FilePath GPResult.exe -ArgumentList "/H "$OutputPath`\GPResults\$gpserver`-GPResult.html" /S $gpserver /F" -ErrorAction SilentlyContinue
					
					Write-Host "    Gathering Texted Generated Output: `'" -NoNewLine -ForegroundColor Cyan
					Write-Host "$gpserver" -NoNewLine -ForegroundColor Magenta
					Write-Host "`'" -ForegroundColor Cyan
					Start-Process -FilePath GPResult.exe -ArgumentList "/Z /F /S $gpserver" -ErrorAction SilentlyContinue | Out-File -FilePath "$OutputPath`\GPResults\$gpserver`-GPResult-Z.txt"
				}
			}
			catch
			{
				Write-Warning $_
				continue
			}
			
			
			
		}
	}
	Write-Output " "
	Write-Output "================================`nGathering System Center Service Manager General Information"
	Write-Host "    Executing Function" -NoNewLine -ForegroundColor Cyan
	Write-Host "-" -NoNewline -ForegroundColor Green
	. $ScriptPath`\Functions\General-Info.ps1
	$collectCompleted = Get-SCSMGeneralInfo -Servers $TestedTLSservers
	do { Write-Host "-" -NoNewline -ForegroundColor Green; sleep 1 }
	until ($collectCompleted)
	Write-Host "> Completed!`n" -NoNewline -ForegroundColor Green
	
	write-output " "
	write-output "================================`n   Wrapping Up`n================================"
	Write-Host "Moving stuff around and zipping everything up for easy transport" -ForegroundColor Gray
	. $ScriptPath`\Functions\Wrapping-Up.ps1
	Wrap-Up
	Write-Host "Script has completed" -ForegroundColor Green -NoNewline
	$x = 1
	do { $x++; Write-Host "." -NoNewline -ForegroundColor Green; Sleep 1 }
	until ($x -eq 3)
	Write-Output " "
	Write-Warning "Exiting script..."
	start C:\Windows\explorer.exe -ArgumentList "/select, $destfile"
	exit 0
}

if ($CheckTLS -or $CheckCertificates -or $GetEventLogs -or $MSInfo32 -or $AssumeYes -or $ExportMPs -or $CaseNumber -or $Servers -or $All -or $GPResult -or $SQLLogs)
{
	if ($all)
	{
		if ($Servers)
		{
			if ($AssumeYes)
			{
				Start-SCSMDataCollector -Servers $Servers -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs -AssumeYes
			}
			Start-SCSMDataCollector -Servers $Servers -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs
		}
		if ($AssumeYes)
		{
			Start-SCSMDataCollector -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -ExportMPs -GPResult -SQLLogs -AssumeYes
		}
		Start-SCSMDataCollector -CheckTLS -CheckCertificates -GetEventLogs -MSInfo32 -GPResult -ExportMPs -SQLLogs
		
	}
	else
	{
		Start-SCSMDataCollector -Servers $Servers -CheckTLS:$CheckTLS -CheckCertificates:$CheckCertificates -GetEventLogs:$GetEventLogs -GPResult:$GPResult -MSInfo32:$MSInfo32 -SQLLogs:$SQLLogs -ExportMPs:$ExportMPs -CaseNumber:$CaseNumber -AssumeYes:$AssumeYes
	}
	
}
#Start Built-in Menu
. $ScriptPath`\Functions\Builtin-Menu.ps1
DataCollector-Menu
# or you can run the below to gather minimal data.
#Start-SCSMDataCollector

Write-Host "ISSUE: Something is wrong, Script has been stopped" -ForegroundColor Yellow -NoNewline
$x = 1
do { $x++; Write-Host "." -NoNewline -ForegroundColor Yellow; Sleep 1 }
until ($x -eq 3)
Write-Output " "
Write-Warning "Exiting script..."
exit 1