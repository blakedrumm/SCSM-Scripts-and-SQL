SELECT TOP 1000 [InternalJobHistoryId] 
,[TimeStarted] 
,[TimeFinished] 
,[StatusCode] 
,[Command] 
,[Comment] 
FROM [ServiceManager].[dbo].[InternalJobHistory] 
ORDER BY TimeStarted DESC