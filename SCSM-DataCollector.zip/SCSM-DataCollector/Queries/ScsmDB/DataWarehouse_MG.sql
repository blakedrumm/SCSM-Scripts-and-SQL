declare @sql nvarchar(max)
set @sql = 'select '
select @sql = @sql + '[' + column_name +'],'
from information_schema.columns 
where table_name='MT_Microsoft$SystemCenter$ResourceAccessLayer$DwSdkResourceStore' and column_name like 'Server%'
set @sql = left(@sql,len(@sql)-1) -- remove trailing comma
set @sql = @sql + ',DisplayName,BaseManagedEntityId from MT_Microsoft$SystemCenter$ResourceAccessLayer$DwSdkResourceStore'
exec sp_executesql @sql